package Peer;

public class Piece {
    
    public static Piece decodePieceMessagePayload(byte[] msgPayload) {
        Piece p = new Piece();
        return p;
    }

    public int getWhichPiece() {
		return 0;
	}
}
