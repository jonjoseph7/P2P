package Peer;

public class PeerCommonProperties {
    public Integer NumberOfPreferredNeighbors;

    public Integer getNumberPieces() {
        return 0;
    }
}
