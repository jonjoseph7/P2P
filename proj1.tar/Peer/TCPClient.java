package Peer;

public class TCPClient {
    private Peer peer;

    public TCPClient(Peer peer) {
        this.peer = peer;
    }
    public void run() {

    }
}
