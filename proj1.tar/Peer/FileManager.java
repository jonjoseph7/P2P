package Peer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.RandomAccessFile;

import Logging.PeerLogger;

public class FileManager {
    public FileManager(int peerID, boolean hasFile) {
		
	}
}
